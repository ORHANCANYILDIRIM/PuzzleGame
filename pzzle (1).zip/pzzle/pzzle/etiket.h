#ifndef ETIKET_H
#define ETIKET_H

#include <QLabel>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMouseEvent>

class MainWindow;

class etiket : public QLabel
{
    Q_OBJECT
public:
    explicit etiket(QWidget *parent = nullptr);
    QPixmap getResim() const; // Fonksiyonun bildirimi





private:
    void dragEnterEvent(QDragEnterEvent *event);
    void dropEvent(QDropEvent *event);
    void mouseMoveEvent(QMouseEvent *event);


    QPixmap resim; // Yeni üye değişken

    int degisimSayisi; // Değişim sayısını tutacak değişken


signals:


};

#endif // ETIKET_H
