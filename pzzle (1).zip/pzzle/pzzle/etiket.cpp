#include "etiket.h"
#include "mainwindow.h"
#include <QMimeData>
#include <QDrag>

etiket::etiket(QWidget *parent) : QLabel(parent)
{
    setFrameShape(QFrame::Box);
    setScaledContents(true);
    setAcceptDrops(true);

    resim = QPixmap(); // İsterseniz burada varsayılan bir resim de atayabilirsiniz



}



QPixmap etiket::getResim() const {
    return resim;
}


void etiket::dragEnterEvent(QDragEnterEvent *event)
{
    event->accept();
}



void etiket::dropEvent(QDropEvent *event)
{
    etiket *gelen = qobject_cast<etiket*>(event->source());

    if (gelen && gelen != this) {
        QPixmap birakilanPixmap = pixmap()->copy(); // Bu etiketteki resmi kopyalayın
        QPixmap gelenPixmap = gelen->pixmap()->copy(); // Diğer etiketteki resmi kopyalayın



        QPoint currentPos = this->pos();  // Mevcut etiketin konumu
        QPoint gelenPos = gelen->pos();   // Diğer etiketin konumu



             // Sınırlama: X ekseni için
              int xDiff = qAbs(gelenPos.x() - currentPos.x());
              if (xDiff > 150) {
                  return;  // X eksenindeki fark 100 pikselden fazlaysa, yer değiştirme yapma
              }

              // Sınırlama: Y ekseni için
              int yDiff = qAbs(gelenPos.y() - currentPos.y());
              if (yDiff > 150) {
                  return;  // Y eksenindeki fark 100 pikselden fazlaysa, yer değiştirme yapma
              }




         setPixmap(gelenPixmap); // Bu etiketin pixmap'ine diğer etiketin resmini koyun
         gelen->setPixmap(birakilanPixmap); // Diğer etiketin pixmap'ine bu etiketin resmini koyun

         ((MainWindow*)(this->window()))->artirLabelDegeri();

         return;

    }


}

void etiket::mouseMoveEvent(QMouseEvent *event)
{

    QMimeData *mdata = new QMimeData();
    mdata->setImageData(pixmap()->toImage());
    QDrag *suruklenen = new QDrag(this);
    suruklenen->setMimeData(mdata);
    suruklenen->setPixmap(mdata->imageData().value<QPixmap>());
    suruklenen->exec(Qt::MoveAction);
}



