#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFrame>
#include <QLabel>
#include <QPixmap>
#include <QVBoxLayout>
#include <QRandomGenerator>
#include <random>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // Boyut politikalarını belirleme
      this->setSizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);



    QLabel *label = new QLabel(this);
    label->setGeometry(900,75,500,400);

    QString resimYolu = ":/resimler/resimler/puzzle.jpg"; // Resmin yolunu belirtin
    QPixmap resim(resimYolu); // QPixmap ile resmi yükleyin
    label->setPixmap(resim);
    label->setScaledContents(true);
    label->show();


    // Resimleri karıştırma fonksiyonunu çağırın
    shuffleImages();


    QVBoxLayout *mainLayout = new QVBoxLayout(this); // Ana düzen
    QHBoxLayout *rowLayout; // Satır düzeni

    for (int i = 0; i < 5; ++i) {
        rowLayout = new QHBoxLayout; // Yeni bir satır düzeni oluştur
        for (int j = 0; j < 5; ++j) {
            QLabel *etiket = new QLabel; // Yeni bir etiket oluştur
            etiket->setAlignment(Qt::AlignCenter); // Etiketin içeriğini ortala

            QString resimAdi = ":/resimler/resimler/" + QString::number(i * 5 + j) + ".png"; // Resim dosyasının yolu
            QPixmap resim(resimAdi); // Resmi yükle

            etiket->setPixmap(resim); // Etikete resmi ekle
            etiket->setScaledContents(true); // Resmi etiket boyutuna göre ölçekle

            rowLayout->addWidget(etiket); // Etiketi satır düzenine ekle
        }
        mainLayout->addLayout(rowLayout); // Satır düzenini ana düzene ekle
    }

    setLayout(mainLayout); // Ana düzeni pencereye ayarla


}


void MainWindow::artirLabelDegeri() {
    int simdikiDeger = ui->labelsc->text().toInt(); // Etiketin şu anki değerini al
    simdikiDeger++; // Değeri bir artır
    ui->labelsc->setText(QString::number(simdikiDeger)); // Yeni değeri etikete set et
}


void MainWindow::shuffleImages() {
    QStringList resimAdlari;

    // Sıralı şekilde resim adlarını diziye ekleme
    for (int i = 0; i < 25; ++i) {
        QString resimAdi = ":/resimler/resimler/" + QString::number(i) + ".png";
        resimAdlari.append(resimAdi);
    }

    // Resim adlarını karıştırma
       unsigned int seed = std::chrono::system_clock::now().time_since_epoch().count();
       std::shuffle(resimAdlari.begin(), resimAdlari.end(), std::default_random_engine(seed));

    int a = 0;
    int X = 50;
    int Y = 50;

    for (int i = 0; i < 5; ++i) {
        for (int k = 0; k < 5; ++k) {
            etiket *et = new etiket(this);
            et->setGeometry(X, Y, 150, 150);

            QPixmap resim(resimAdlari[a]);
            et->setPixmap(resim);

            a++;
            et->show();
            X += 150;
        }
        X = 50;
        Y += 150;
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

